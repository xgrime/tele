#!/bin/sh
ulang="y"
while [ $ulang = "y" ]
do
python3.8 visit.py -p +12052121906 -c ltc
sleep 15
python3.8 visit.py -p +6281278984825 -c ltc
sleep 15
python3.8 visit.py -p +12053908594 -c ltc
sleep 15
python3.8 visit.py -p +6281335898571 -c ltc
sleep 15
python3.8 visit.py -p +12055585267 -c ltc
sleep 15
python3.8 visit.py -p +6282178708675 -c ltc
sleep 15
python3.8 visit.py -p +12055731755 -c ltc
sleep 15
python3.8 visit.py -p +6282179377408 -c ltc
sleep 15
python3.8 visit.py -p +12055820978-c ltc
sleep 15
python3.8 visit.py -p +12055905587-c ltc
sleep 15
python3.8 visit.py -p +6282380341737 -c ltc
sleep 15
python3.8 visit.py -p +12056152328-c ltc
sleep 15
python3.8 visit.py -p +6283126997146-c ltc
sleep 15
python3.8 visit.py -p +12056564451-c ltc
sleep 15
python3.8 visit.py -p +6283198569717-c ltc
sleep 15
python3.8 visit.py -p +6283198569731-c ltc
sleep 15
python3.8 visit.py -p +12056901867-c ltc
sleep 15
python3.8 visit.py -p +6283226997146-c ltc
sleep 15
python3.8 visit.py -p +12057198210-c ltc
sleep 15
python3.8 visit.py -p +6285211385738-c ltc
sleep 15
python3.8 visit.py -p +12076130874-c ltc
sleep 15
python3.8 visit.py -p +6285311385738-c ltc
sleep 15
python3.8 visit.py -p +12076890583-c ltc
sleep 15
python3.8 visit.py -p +6285369089629-c ltc
sleep 15
python3.8 visit.py -p +12084378125-c ltc
sleep 15
python3.8 visit.py -p +12084378125-c ltc
sleep 15
python3.8 visit.py -p +6285788824312-c ltc
sleep 15
python3.8 visit.py -p +15808255471-c ltc
sleep 15
python3.8 visit.py -p +6285832590504-c ltc
sleep 15
python3.8 visit.py -p +2057198210-c ltc
sleep 15
python3.8 visit.py -p +6285839403082-c ltc
sleep 15
python3.8 visit.py -p +6281278964288-c ltc
sleep 15
python3.8 visit.py -p +628990809421
sleep 21600
done