#!/bin/sh
ulang="y"
while [ $ulang = "y" ]
do
python3.7 visit.py -p +6282179377408 -c ltc &
sleep 35
python3.7 visit.py -p +6285211385738 -c ltc &
sleep 35
python3.7 visit.py -p +6285788824312 -c ltc &
sleep 35
python3.7 visit.py -p +6282380341737 -c ltc &
sleep 35
python3.7 visit.py -p +6285832590504 -c ltc &
sleep 35
python3.7 visit.py -p +2057198210 -c ltc &
sleep 35
python3.7 visit.py -p +12076890583 -c ltc &
sleep 35
python3.7 visit.py -p +12055820978 -c ltc &
sleep 35
python3.7 visit.py -p +12084378125 -c ltc &
sleep 7200
done